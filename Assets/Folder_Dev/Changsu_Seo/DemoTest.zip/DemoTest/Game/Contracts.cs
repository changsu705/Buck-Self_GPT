using System;
using System.Collections.Generic;

namespace Buckshot.Contracts
{
    /// <summary>ź ����</summary>
    public enum ShellType { Blank = 0, Live = 1 }

    /// <summary>�� ��û DTO (Ŭ���̾�Ʈ �� ȣ��Ʈ)</summary>
    public struct ShootRequest
    {
        public int ShooterActor;   // �� �÷��̾�
        public int TargetActor;    // �´� ���
    }

    /// <summary>�� ���� ��� DTO (ȣ��Ʈ �� ��� Ŭ���̾�Ʈ)</summary>
    public struct ShotResult
    {
        public int ShooterActor;
        public int TargetActor;
        public ShellType Shell;
        public int NewTargetHp;
        public bool IsRoundOver;
        public int NextTurnActor;
    }

    public interface IReadonlyGameState
    {
        int CurrentTurnActor { get; }
        int ShellIndex { get; }
        ShellType[] Shells { get; }
        int GetHp(int actor);
        int GetOpponent(int me);
        bool HasShellLeft { get; }
    }

    public interface IGameStateStore
    {
        int CurrentTurnActor { get; }
        int ShellIndex { get; }
        ShellType[] Shells { get; }
        int GetHp(int actor);

        void SetCurrentTurn(int actor);
        void SetShellIndex(int index);
        void SetShells(ShellType[] shells);
        void SetHp(int actor, int hp);

        IEnumerable<int> AllActors { get; }
    }

    public interface IShellDeckBuilder
    {
        ShellType[] Build(int seed, int liveCount, int blankCount);
    }

    public interface IFirstTurnPolicy
    {
        int PickFirstActor(IReadOnlyList<int> actorNumbers, int seed);
    }

    public interface IRuleEngine
    {
        ShotResult ResolveShot(IReadonlyGameState state, ShootRequest request);
    }

    public interface INetTransport
    {
        void SendShootRequestToHost(ShootRequest req);
        void BroadcastShotResult(ShotResult result);
        void BroadcastNewRound();
    }
}
